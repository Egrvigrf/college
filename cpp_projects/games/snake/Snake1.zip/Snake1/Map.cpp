#include"Snake.h"
void setmap()
{
    short x;
    short y;
    srand((unsigned)time(NULL));
    colorset(14);
    Map[head.x][head.y] = '*';
    len = 1;
    snk_is_alive = true;
    food1_notexist = true;
    colorset(9);
    switch(gamechoose) {
    case 'a': { //经典
        maplength = 12;
        mapwidth = 15;
        for(int i = 0; i <= maplength; i++) {
            for(int j = 0; j <= mapwidth; j++) {
                Map[i][j] = ' ';
            }
        }
        gotoxy(maplength+1,mapwidth+1);
        break;
    }
    case 'b': { //箱子
        for(int i = 0; i <= maplength; i++) {
            for(int j = 0; j <= mapwidth; j++) {
                Map[i][j] = ' ';
            }
        }
        Map[0][0] = '#';
        gotoxy(0,0);
        cout<<"#";
        Map[0][1] = '#';
        gotoxy(0,1);
        cout<<"#";
        Map[1][0] = '#';
        gotoxy(1,0);
        cout<<"#";
        Map[maplength-1][0] = '#';
        gotoxy(maplength-1,0);
        cout<<"#";
        Map[maplength][0] = '#';
        gotoxy(maplength,0);
        cout<<"#";
        Map[maplength][1] = '#';
        gotoxy(maplength,1);
        cout<<"#";
        Map[0][mapwidth] = '#';
        gotoxy(0,mapwidth);
        cout<<"#";
        Map[0][mapwidth-1] = '#';
        gotoxy(0,mapwidth-1);
        cout<<"#";
        Map[1][mapwidth] = '#';
        gotoxy(1,mapwidth);
        cout<<"#";
        Map[maplength][mapwidth] = '#';
        gotoxy(maplength,mapwidth);
        cout<<"#";
        Map[maplength][mapwidth-1] = '#';
        gotoxy(maplength,mapwidth-1);
        cout<<"#";
        Map[maplength-1][mapwidth] = '#';
        gotoxy(maplength-1,mapwidth);
        cout<<"#";
        gotoxy(maplength+1,mapwidth+1);
        break;
    }
    case 'c' : {
        for(int i = 0; i <= maplength; i++) {
            for(int j = 0; j <= mapwidth; j++) {
                Map[i][j] = ' ';
            }
        }
        for(short i = 4; i <= 7; i++) {
            Map[i][0] = '#';
            gotoxy(i,0);
            cout<<"#";
            Map[i][7] = '#';
            gotoxy(i,7);
            cout<<"#";
            Map[i][15] = '#';
            gotoxy(i,15);
            cout<<"#";
        }
        break;
    }
    case 'd' : { //磨坊
        for(int i = 0; i <= maplength; i++) {
            for(int j = 0; j <= mapwidth; j++) {
                Map[i][j] = ' ';
            }
        }
        for(int i = 0; i <= maplength; i++) {
            Map[i][7] = '#';
            gotoxy(i,7);
            cout<<"#";
        }
        break;
    }
    case 'e' : { //铁轨
        for(int i = 0; i <= maplength; i++) {
            for(int j = 0; j <= mapwidth; j++) {
                Map[i][j] = ' ';
            }
        }
        for(int i = 0; i <= 7; i++) {
            Map[i][7] = '#';
            gotoxy(i,7);
            cout<<"#";
        }
        for(int i = 0; i <= 5; i++) {
            Map[7][i] = '#';
            gotoxy(7,i);
            cout<<"#";
        }
        break;
    }
    case 'f' : { //公寓
        for(int i = 0; i <= maplength; i++) {
            for(int j = 0; j <= mapwidth; j++) {
                Map[i][j] = ' ';
            }
        }
        for(int i = 0; i <= 4; i++) {
            Map[4][i] = '#';
            gotoxy(4,i);
            cout<<"#";
        }
        for(int i = 4; i <= maplength; i++) {
            Map[i][4] = '#';
            gotoxy(i,4);
            cout<<"#";
        }
        for(int i = 0; i <= 7; i++) {
            Map[i][11] = '#';
            gotoxy(i,11);
            cout<<"#";
        }
        for(int i = 11; i <= mapwidth; i++) {
            Map[7][i] = '#';
            gotoxy(7,i);
            cout<<"#";
        }
        colorset(255);
        for(short i = 0; i<=mapwidth+1; i++) {
            gotoxy(maplength+1,i);
            cout<<" ";
        }
        for(short i = 0; i<=maplength; i++) {
            gotoxy(i,mapwidth+1);
            cout<<" ";
        }
        colorset(9);
        break;
    }
    case 'g': { //围城
        for(short i=0; i<=maplength; i++) {
            Map[i][0]='#';//打印并在地图上储存上行，下行
            gotoxy(i,0);
            cout<<"#";
            Map[i][mapwidth]='#';
            gotoxy(i,mapwidth);
            cout<<"#";
        }
        for(short i=1; i<=mapwidth-1; i++) {
            Map[0][i]='#';//打印并储存左列，右列
            gotoxy(0,i);
            cout<<"#";
            Map[maplength][i]='#';
            gotoxy(maplength,i);
            cout<<"#";
        }
        for(short i=1; i<=maplength-1; i++) {
            for(int j=1; j <= mapwidth-1; j++) {
                Map[i][j]=' ';
                gotoxy(i,j);
                cout<<" ";
            }
        }
        break;
    }
    case 'h': { //随机障碍
        for(short i=0; i<=maplength; i++) {
            Map[i][0]='#';//打印并在地图上储存上行，下行
            gotoxy(i,0);
            cout<<"#";
            Map[i][mapwidth]='#';
            gotoxy(i,mapwidth);
            cout<<"#";
        }
        for(short i=1; i<=mapwidth-1; i++) {
            Map[0][i]='#';//打印并储存左列，右列
            gotoxy(0,i);
            cout<<"#";
            Map[maplength][i]='#';
            gotoxy(maplength,i);
            cout<<"#";
        }
        for(short i=1; i<=maplength-1; i++) {
            for(int j=1; j <= mapwidth-1; j++) {
                Map[i][j]=' ';
                gotoxy(i,j);
                cout<<" ";
            }
        }
        int num = rand()%5+5;
        int _x;
        int _y;
        for(int j = 1; j<= num; j++) {
            do {
                _x = rand()%(maplength-1)+1;
                _y = rand()%(mapwidth-1)+1;
            } while (Map[_x][_y] != ' ');
            Map[_x][_y] = '#';
            gotoxy(_x,_y);
            cout<<"#";
        }
        break;
    }
    case 'i': {
        if (dm.around == true) {
            for (int i = 0;i <= dm.l; i++) {
                Map[i][0] = '#';
                gotoxy(i,0);
                cout<<"#";
                Map[i][dm.w] = '#';
                gotoxy(i,dm.w);
                cout<<"#";
            }
            for(short j = 1;j <= dm.w - 1; j++) {
                Map[0][j] = '#';
                gotoxy(0,j);
                cout<<"#";
                Map[dm.w][j] = '#';
                gotoxy(dm.w,j);
                cout<<"#";
            }
            for(short l = 1;l <= dm.l - 1; l++) {
                for (short w = 1;w <= dm.w - 1; w++) {
                    Map[l][w] = ' ';
                    gotoxy(l,w);
                    cout<<" ";
                }
            }
        } else {
            for(short l = 0;l <= dm.l; l++) {
                for (short w = 0;w <= dm.w; w++) {
                    Map[l][w] = ' ';
                    gotoxy(l,w);
                    cout<<" ";
                }
            }
        }
        if (dm.num > 0) {
            for(short n = 1; n <= dm.num; n++) {
                short x,y;
                do {
                    x = rand()%(dm.l-1)+1;
                    y = rand()%(dm.w-1)+1;
                }
                while (Map[x][y] != ' ');
                Map[x][y] = '#';
                gotoxy(x,y);
                cout<<"#";
            }
            maplength = dm.l;
            mapwidth = dm.w;
        }
        break;
    }
    default : {
    }
    }
    gotoxy(maplength+1,mapwidth+1);//打印隐形边界
        colorset(255);
        for(short i = 0; i<=mapwidth+1; i++) {
            gotoxy(maplength+1,i);
            cout<<" ";
        }
        for(short i = 0; i<=maplength; i++) {
            gotoxy(i,mapwidth+1);
            cout<<" ";
        }
    gotoxy(maplength+2,0);
    colorset(10);
    cout<<"您的得分：0";
    gotoxy(maplength+2,1);
    colorset(12);
    cout<<"历史最高："<<hmark;
    colorset(15);
    gotoxy(maplength+2,2);
    cout<<"地图：";
    switch(gamechoose) {
    case 'a': {
        cout<<"经典\n";
        break;
    }
    case 'b': {
        cout<<"箱子\n";
        break;
    }
    case 'c': {
        cout<<"隧道\n";
        break;
    }
    case 'd': {
        cout<<"磨坊\n";
        break;
    }
    case 'e': {
        cout<<"铁轨\n";
        break;
    }
    case 'f': {
        cout<<"公寓\n";
        break;
    }
    case 'g': {
        cout<<"围城\n";
        break;
    }
    case 'h': {
        cout<<"围城—随机地图\n";
        break;
    }
    case 'i': {
        cout<<"自定义\n";
        break;
    }
    default: {
    }
    }
    gotoxy(maplength+2,3);
    cout<<"状态：游戏中";
    colorset(14);
    food1(food1_notexist);
    do {
        x = rand()%(maplength+1);
        y = rand()%(mapwidth+1);
    } while(Map[x][y] != ' ');
    head = { x,y };
    tail = { x,y };
    gotoxy(head.x,head.y);
    cout<<"@";
    short a1;
    bool a2 = false;
    while(a2 != true) {
        a1 = getch();
    switch(a1) {
    case 100:
        dir=1;
        a2 = true;
        break;
    case 97 :
        dir=2;
        a2 = true;
        break;
    case 115:
        dir=3;
        a2 = true;
        break;
    case 119:
        dir=4;
        a2 = true;
        break;
    default:
        break;
    }
    }
    dirold = dir;
}

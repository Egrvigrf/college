#include"Snake.h"
void gotoxy(short x, short y)
{
    COORD pos = {x,y};
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);// 获取标准输出设备句柄
    SetConsoleCursorPosition(hOut, pos);//两个参数分别是指定哪个窗体，具体位置
}
void dirchange(void)
{
    char ch;
    if(kbhit()) {
        ch = getch();
    }
    switch(ch) {
    case 100:
        dirold = dir;
        dir=1;
        break;
    case 97 :
        dirold = dir;
        dir=2;
        break;
    case 115:
        dirold = dir;
        dir=3;
        break;
    case 119:
        dirold = dir;
        dir=4;
        break;
    case 32:
        if(sound_is_on) {
            PlaySound("pause1.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
        }
        gotoxy(maplength+12,3);
        colorset(15);
        cout<<"暂停";
        while(true) {
            char ch = getch();
            if(ch == 32) {
                if(sound_is_on) {
                    PlaySound("pause2.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                }
                break;
            }
        }
        gotoxy(maplength+12,3);
        cout<<"中  ";
        break;
    default:
        dirold = dir;
        break;
    }
    if(len != 1) {  //当方向冲突时方向更改无效，即等于原方向
        if(!(dirop(dir,dirold))) {
            dir = dirold;
        }
    }
}
bool dirop(short dir,short dirold)      //判断蛇反向无效
{
    switch(dir) {
    case 1:
        if(dirold == 2) {
            return false;
        } else {
            return true;
        }
        break;
    case 2:
        if(dirold == 1) {
            return false;
        } else {
            return true;
        }
        break;
    case 3:
        if(dirold == 4) {
            return false;
        } else {
            return true;
        }
        break;
    case 4:
        if(dirold == 3) {
            return false;
        } else {
            return true;
        }
        break;
    default :
        break;
        return true;
    }
}
void printlogo(void)
{
    colorset(112);
    for (short x = 0; x <= 7; x++) {
        for (short y = 0; y <= 9; y++) {
            gotoxy(x,y);
            cout<<" ";
            Sleep(25);
        }
    }
    gotoxy(3,7);
    cout<<"#";
    Sleep(100);
    gotoxy(3,8);
    cout<<"#";
    Sleep(80);
    gotoxy(3,6);
    cout<<"#";
    Sleep(60);
    gotoxy(2,7);
    cout<<"#";
    gotoxy(4,7);
    cout<<"#";
    gotoxy(3,5);
    cout<<"#";
    Sleep(50);
    gotoxy(3,4);
    cout<<"#";
    Sleep(50);
    gotoxy(2,3);
    cout<<"#";
    gotoxy(4,3);
    cout<<"#";
    Sleep(100);
    gotoxy(1,2);
    cout<<"#";
    gotoxy(3,2);
    cout<<"#";
    gotoxy(5,2);
    cout<<"#";
    Sleep(75);
    gotoxy(2,1);
    cout<<"#";
    gotoxy(4,1);
    cout<<"#";
    Sleep(100);
    gotoxy(3,0);
    cout<<"#";
    gotoxy(0,9);
    Sleep(100);
    cout<<"Flashoak";
    gotoxy(0,10);
    cout<<"21.2.26 ";
    Sleep(2500);
    colorset(15);
}
void welcome(void)
{
    SetConsoleTitle("贪吃蛇");
    CONSOLE_CURSOR_INFO cursor_info = {1,0};
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);//隐藏控制台光标
    system("mode con cols=50 lines=32");//设置控制台窗口大小
    cout<<"贪吃蛇\n";
    Sleep(500);
    cout<<"按'a' 's' 'd' 'w'以控制/选择\n";
    Sleep(400);
    cout<<"按回车以确认\n";
    Sleep(400);
    cout<<"按Esc以返回\n";
    Sleep(400);
    cout<<"按空格以暂停\n";
    Sleep(400);
    cout<<"当蛇头碰到障碍物或蛇身时游戏结束\n";
    cout<<"若继续，请确认\n";
    while (TRUE) {
        char ch = getch();
        if (ch == 13) {
            if(sound_is_on == true) {
                PlaySound("enter.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
            }
            break;
        }
    }
    system("cls");
    printlogo();
    system("cls");
}
void gameset(void)
{
    maplength = 12;
    mapwidth = 15;  //规模：(maplength+1) * (mapwidth+1)
    dm.around = false;
    dm.l = 12;
    dm.w = 15;
    dm.num = 0;
    gamechoose = 'a';
    sound_is_on = true;
    speed = 300;
    short spcontr = 1;
    short a_y,a_yold;
    a_y = 0;
    colorset(112);
    cout<<"新游戏\n";  //0
    colorset(15);
    cout<<"难度\n";    //1
    cout<<"游戏类型\n";//2
    cout<<"声音\n";    //3
    bool flag = false;
    while(flag != true) {   //LEFT ARROW 键(←):a    UP ARROW键(↑):w     RIGHT ARROW键(→):d  DOWN ARROW键(↓):s   enter:13 esc:27
        switch(char ch1 = getch()) {
        case 'w': { //上
            if(sound_is_on == true) {
                PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
            }
            if(a_y == 0) {
                a_y = 3;
            } else {
                a_y--;
            }
            switch(a_y) {
            case 0: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"新游戏";
                colorset(15);
                gotoxy(0,1);
                cout<<"难度";
                break;
            }
            case 1: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"难度";
                colorset(15);
                gotoxy(0,2);
                cout<<"游戏类型";
                break;
            }
            case 2: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"游戏类型";
                colorset(15);
                gotoxy(0,3);
                cout<<"声音";
                break;
            }
            case 3: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"声音";
                colorset(15);
                gotoxy(0,0);
                cout<<"新游戏";
                break;
            }
            default: {
            }
            }
            break;
        }
        case 's': { //下
            if(sound_is_on == true) {
                PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
            }
            if(a_y == 3) {
                a_y = 0;
            } else {
                a_y++;
            }
            switch(a_y) {
            case 0: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"新游戏";
                colorset(15);
                gotoxy(0,3);
                cout<<"声音";
                break;
            }
            case 1: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"难度";
                colorset(15);
                gotoxy(0,0);
                cout<<"新游戏";
                break;
            }
            case 2: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"游戏类型";
                colorset(15);
                gotoxy(0,1);
                cout<<"难度";
                break;
            }
            case 3: {
                gotoxy(0,a_y);
                colorset(112);
                cout<<"声音";
                colorset(15);
                gotoxy(0,2);
                cout<<"游戏类型";
                break;
            }
            default: {
            }
            }
            break;
        }
        case 13:
            if(sound_is_on == true) {
                PlaySound("enter.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
            }
            switch(a_y) {
            case 0: {
                flag = true;
                break;
            }
            case 1: {
                bool fl = false;
                system("cls");
                gotoxy(0,0);
                cout<<"游戏难度：<";
                colorset(112);
                cout<<spcontr;
                colorset(15);
                cout<<">";
                while(fl != true) {
                    char ch;
                    ch = getch();
                    switch(ch) {
                    case 'a': {
                        if(sound_is_on == true) {
                            PlaySound("leftright.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        if(spcontr == 1) {
                            spcontr = 9;
                            speed = 100;
                        } else {
                            spcontr--;
                            speed = speed+25;
                        }
                        gotoxy(11,0);
                        colorset(112);
                        cout<<spcontr;
                        colorset(15);
                        break;
                    }
                    case 'd': {
                        if(sound_is_on == true) {
                            PlaySound("leftright.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        if(spcontr == 9) {
                            spcontr = 1;
                            speed = 300;
                        } else {
                            spcontr++;
                            speed = speed-25;
                        }
                        gotoxy(11,0);
                        colorset(112);
                        cout<<spcontr;
                        colorset(15);
                        break;
                    }
                    case 27: {
                        if(sound_is_on == true) {
                            PlaySound("esc.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        system("cls");
                        gotoxy(0,0);
                        cout<<"新游戏\n";  //0
                        colorset(112);
                        cout<<"难度\n";
                        colorset(15);    //1
                        cout<<"游戏类型\n";//2
                        cout<<"声音\n";
                        fl = true;
                        break;
                    }
                    default: {
                    }
                    }
                }
                break;
            }
            case 2: {
                system("cls");
                char c;
                short y = 1;
                bool fg = false;
                gotoxy(0,0);
                cout<<"游戏地图状态：";//0
                switch(gamechoose) {
                case 'a': {
                    cout<<"经典\n";
                    break;
                }
                case 'b': {
                    cout<<"箱子\n";
                    break;
                }
                case 'c': {
                    cout<<"隧道\n";
                    break;
                }
                case 'd': {
                    cout<<"磨坊\n";
                    break;
                }
                case 'e': {
                    cout<<"铁轨\n";
                    break;
                }
                case 'f': {
                    cout<<"公寓\n";
                    break;
                }
                case 'g': {
                    cout<<"围城\n";
                    break;
                }
                case 'h': {
                    cout<<"围城—随机地图\n";
                    break;
                }
                case 'i': {
                    cout<<"自定义\n";
                    break;
                }
                default: {
                }
                }
                if(gamechoose == 'a') {
                    y = 1;
                    colorset(112);
                }
                cout<<"经典\n";
                colorset(15);
                if(gamechoose == 'b') {
                    y = 2;
                    colorset(112);
                }
                cout<<"箱子\n";
                colorset(15);
                if(gamechoose == 'c') {
                    y = 3;
                    colorset(112);
                }
                cout<<"隧道\n";
                colorset(15);
                if(gamechoose == 'd') {
                    y = 4;
                    colorset(112);
                }
                cout<<"磨坊\n";
                colorset(15);
                if(gamechoose == 'e') {
                    y = 5;
                    colorset(112);
                }
                cout<<"铁轨\n";
                colorset(15);
                if(gamechoose == 'f') {
                    y = 6;
                    colorset(112);
                }
                cout<<"公寓\n";
                colorset(15);
                if(gamechoose == 'g') {
                    y = 7;
                    colorset(112);
                }
                cout<<"围城\n";
                colorset(15);
                if(gamechoose == 'h') {
                    y = 8;
                    colorset(112);
                }
                cout<<"围城—随机地图\n";
                colorset(15);
                if(gamechoose == 'i') {
                    y = 9;
                    colorset(112);
                }
                cout<<"自定义\n";
                colorset(15);
                while(fg != true) {
                    c = getch();
                    switch(c) {
                    case 'w': { //上
                        if(sound_is_on == true) {
                            PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        if(y == 1) {
                            y = 9;
                        } else {
                            y--;
                        }
                        switch(y) {
                        case 1: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"经典";
                            colorset(15);
                            gotoxy(0,2);
                            cout<<"箱子";
                            break;
                        }
                        case 2: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"箱子";
                            colorset(15);
                            gotoxy(0,3);
                            cout<<"隧道";
                            break;
                        }
                        case 3: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"隧道";
                            colorset(15);
                            gotoxy(0,4);
                            cout<<"磨坊";
                            break;
                        }
                        case 4: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"磨坊";
                            colorset(15);
                            gotoxy(0,5);
                            cout<<"铁轨";
                            break;
                        }
                        case 5: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"铁轨";
                            colorset(15);
                            gotoxy(0,6);
                            cout<<"公寓";
                            break;
                        }
                        case 6: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"公寓";
                            colorset(15);
                            gotoxy(0,7);
                            cout<<"围城";
                            break;
                        }
                        case 7: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"围城";
                            colorset(15);
                            gotoxy(0,8);
                            cout<<"围城—随机障碍";
                            break;
                        }
                        case 8: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"围城—随机障碍";
                            colorset(15);
                            gotoxy(0,9);
                            cout<<"自定义";
                            break;
                        }
                        case 9: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"自定义";
                            colorset(15);
                            gotoxy(0,1);
                            cout<<"经典";
                            break;
                        }
                        default: {
                        }
                        }
                        break;
                    }
                    case 's': { //下
                        if(sound_is_on == true) {
                            PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        if(y == 9) {
                            y = 1;
                        } else {
                            y++;
                        }
                        switch(y) {
                        case 1: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"经典";
                            colorset(15);
                            gotoxy(0,9);
                            cout<<"自定义";
                            break;
                        }
                        case 2: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"箱子";
                            colorset(15);
                            gotoxy(0,1);
                            cout<<"经典";
                            break;
                        }
                        case 3: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"隧道";
                            colorset(15);
                            gotoxy(0,2);
                            cout<<"箱子";
                            break;
                        }
                        case 4: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"磨坊";
                            colorset(15);
                            gotoxy(0,3);
                            cout<<"隧道";
                            break;
                        }
                        case 5: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"铁轨";
                            colorset(15);
                            gotoxy(0,4);
                            cout<<"磨坊";
                            break;
                        }
                        case 6: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"公寓";
                            colorset(15);
                            gotoxy(0,5);
                            cout<<"铁轨";
                            break;
                        }
                        case 7: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"围城";
                            colorset(15);
                            gotoxy(0,6);
                            cout<<"公寓";
                            break;
                        }
                        case 8: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"围城—随机障碍";
                            colorset(15);
                            gotoxy(0,7);
                            cout<<"围城";
                            break;
                        }
                        case 9: {
                            gotoxy(0,y);
                            colorset(112);
                            cout<<"自定义";
                            colorset(15);
                            gotoxy(0,8);
                            cout<<"围城—随机障碍";
                            break;
                        }
                        default: {
                        }
                        }
                        break;
                    }
                    case 13: {
                        if(sound_is_on == true) {
                            PlaySound("enter.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        switch(y) {
                        case 1: {
                            gamechoose = 'a';
                            gotoxy(14,0);
                            cout<<"经典     ";
                            break;
                        }
                        case 2: {
                            gamechoose = 'b';
                            gotoxy(14,0);
                            cout<<"箱子          ";
                            break;
                        }
                        case 3: {
                            gamechoose = 'c';
                            gotoxy(14,0);
                            cout<<"隧道          ";
                            break;
                        }
                        case 4: {
                            gamechoose = 'd';
                            gotoxy(14,0);
                            cout<<"磨坊          ";
                            break;
                        }
                        case 5: {
                            gamechoose = 'e';
                            gotoxy(14,0);
                            cout<<"铁轨          ";
                            break;
                        }
                        case 6: {
                            gamechoose = 'f';
                            gotoxy(14,0);
                            cout<<"公寓          ";
                            break;
                        }
                        case 7: {
                            gamechoose = 'g';
                            gotoxy(14,0);
                            cout<<"围城          ";
                            break;
                        }
                        case 8: {
                            gamechoose = 'h';
                            gotoxy(14,0);
                            cout<<"围城—随机障碍";
                            break;
                        }
                        case 9: {
                            gamechoose = 'i';
                            gotoxy(14,0);
                            cout<<"自定义        ";
                            system("cls");
                            cout<<"地图长度：<";
                            colorset(112);
                            cout<<dm.l;
                            colorset(15);
                            cout<<">\n";
                            cout<<"地图宽度：<"<<dm.w<<">\n";
                            cout<<"是否围城：否\n";
                            cout<<"是\n";
                            cout<<"否\n";
                            cout<<"随机障碍物数量：<"<<dm.num<<">个\n";
                            short y2 = 0;
                            bool f = false;
                            while (f != true) {
                                char ch;
                                ch = getch();
                                switch (ch) {
                                case 'w': {     //上
                                    if(sound_is_on == true) {
                                        PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                                    }
                                    if (y2 == 0) {
                                        y2 = 5;
                                    } else if (y2 == 3) {
                                        y2 = 1;
                                    } else {
                                        y2 --;
                                    }
                                    switch(y2) {
                                    case 0: {
                                        gotoxy(11,1);
                                        cout<<dm.w<<">";
                                        gotoxy(11,y2);
                                        colorset(112);
                                        cout<<dm.l;
                                        colorset(15);
                                        cout<<">";
                                        break;
                                    }
                                    case 1: {
                                        gotoxy(0,3);
                                        cout<<"是";
                                        gotoxy(11,y2);
                                        colorset(112);
                                        cout<<dm.w;
                                        colorset(15);
                                        cout<<">";
                                        break;
                                    }
                                    case 3: {
                                        gotoxy(0,4);
                                        cout<<"否";
                                        gotoxy(0,y2);
                                        colorset(112);
                                        cout<<"是";
                                        colorset(15);
                                        break;
                                    }
                                    case 4: {
                                        gotoxy(17,5);
                                        cout<<dm.num<<">";
                                        gotoxy(0,y2);
                                        colorset(112);
                                        cout<<"否";
                                        colorset(15);
                                        break;
                                    }
                                    case 5: {
                                        gotoxy(11,0);
                                        cout<<dm.l<<">";
                                        gotoxy(17,5);
                                        colorset(112);
                                        cout<<dm.num;
                                        colorset(15);
                                        cout<<">";
                                        break;
                                    }
                                    default: {
                                    }
                                    }
                                    break;
                                }
                                case 's': { //下
                                    if(sound_is_on == true) {
                                        PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                                    }
                                    if (y2 == 5) {
                                        y2 = 0;
                                    } else if (y2 == 1) {
                                        y2 = 3;
                                    } else {
                                        y2 ++;
                                    }
                                    switch(y2) {
                                    case 0: {
                                        gotoxy(17,5);
                                        cout<<dm.num<<">";
                                        gotoxy(11,y2);
                                        colorset(112);
                                        cout<<dm.l;
                                        colorset(15);
                                        cout<<">";
                                        break;
                                    }
                                    case 1: {
                                        gotoxy(11,0);
                                        cout<<dm.l<<">";
                                        gotoxy(11,y2);
                                        colorset(112);
                                        cout<<dm.w;
                                        colorset(15);
                                        cout<<">";
                                        break;
                                    }
                                    case 3: {
                                        gotoxy(11,1);
                                        cout<<dm.w<<">";
                                        gotoxy(0,y2);
                                        colorset(112);
                                        cout<<"是";
                                        colorset(15);
                                        break;
                                    }
                                    case 4: {
                                        gotoxy(0,3);
                                        cout<<"是";
                                        gotoxy(0,y2);
                                        colorset(112);
                                        cout<<"否";
                                        colorset(15);
                                        break;
                                    }
                                    case 5: {
                                        gotoxy(0,4);
                                        cout<<"否";
                                        gotoxy(17,5);
                                        colorset(112);
                                        cout<<dm.num;
                                        colorset(15);
                                        cout<<">";
                                        break;
                                    }
                                    default: {
                                    }
                                    }
                                    break;
                                }
                                case 'a': {
                                    if(sound_is_on == true) {
                                        PlaySound("leftright.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                                    }
                                    if (y2 == 0) {
                                        if (dm.l == 3) {
                                            dm.l = 30;
                                        } else {
                                            dm.l --;
                                        }
                                        colorset(112);
                                        gotoxy(11,0);
                                        cout<<dm.l;
                                        colorset(15);
                                        cout<<">";
                                        if (dm.l == 9) {
                                            gotoxy(13,0);
                                            cout<<" ";
                                        }

                                        if (dm.num > short((dm.l-1)*(dm.w-1)/5)) {
                                            dm.num = short((dm.l-1)*(dm.w-1)/5);
                                            gotoxy(17,5);
                                            cout<<dm.num<<">";
                                        }
                                    } else if (y2 == 1) {
                                        if (dm.w == 3) {
                                            dm.w = 30;
                                        } else {
                                            dm.w --;
                                        }
                                        colorset(112);
                                        gotoxy(11,1);
                                        cout<<dm.w;
                                        colorset(15);
                                        cout<<">";
                                        if (dm.w == 9) {
                                            gotoxy(13,1);
                                            cout<<" ";
                                        }
                                        if (dm.num > short((dm.l-1)*(dm.w-1)/5)) {
                                            dm.num = short((dm.l-1)*(dm.w-1)/5);
                                            gotoxy(17,5);
                                            cout<<dm.num<<">";
                                        }
                                    } else if (y2 == 5) {
                                        if (dm.num == 0) {
                                            dm.num = short((dm.l-1)*(dm.w-1)/5);
                                        } else {
                                            dm.num --;
                                        }
                                        colorset(112);
                                        gotoxy(17,5);
                                        cout<<dm.num;
                                        colorset(15);
                                        cout<<">";
                                        if (dm.num == 9) {
                                            gotoxy(19,5);
                                            cout<<" ";
                                        } else if(dm.num == 99) {
                                            gotoxy(20,5);
                                            cout<<" ";
                                        }
                                    }
                                    break;
                                }
                                case 'd': {
                                    if(sound_is_on == true) {
                                        PlaySound("leftright.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                                    }
                                    if (y2 == 0) {
                                        if (dm.l == 30) {
                                            dm.l = 3;
                                            gotoxy(13,0);
                                            cout<<" ";
                                        } else {
                                            dm.l ++;
                                        }
                                        colorset(112);
                                        gotoxy(11,0);
                                        cout<<dm.l;
                                        colorset(15);
                                        cout<<">";
                                    } else if (y2 == 1) {
                                        if (dm.w == 30) {
                                            dm.w = 3;
                                            gotoxy(13,1);
                                            cout<<" ";
                                        } else {
                                            dm.w ++;
                                        }
                                        colorset(112);
                                        gotoxy(11,1);
                                        cout<<dm.w;
                                        colorset(15);
                                        cout<<">";
                                    } else if (y2 == 5) {
                                        if (dm.num == short((dm.l-1)*(dm.w-1)/5)) {
                                            dm.num = 0;
                                            gotoxy(19,5);
                                            cout<<"  ";
                                        } else {
                                            dm.num ++;
                                        }
                                        colorset(112);
                                        gotoxy(17,5);
                                        cout<<dm.num;
                                        colorset(15);
                                        cout<<">";
                                    }
                                    break;
                                }
                                case 13: {
                                    if(sound_is_on == true) {
                                        PlaySound("enter.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                                    }
                                    if(y2 == 3) {
                                        gotoxy(10,2);
                                        dm.around = true;
                                        cout<<"是";
                                    } else if(y2 == 4) {
                                        gotoxy(10,2);
                                        dm.around = false;
                                        cout<<"否";
                                    }
                                    break;
                                }
                                case 27: {
                                    if(sound_is_on == true) {
                                        PlaySound("esc.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                                    }
                                    system("cls");
                                    cout<<"游戏地图状态：自定义\n";//0
                                    cout<<"经典\n"; //a   1
                                    cout<<"箱子\n";//b    2
                                    cout<<"隧道\n";//c    3
                                    cout<<"磨坊\n";//d    4
                                    cout<<"铁轨\n";//e    5
                                    cout<<"公寓\n";//f    6
                                    cout<<"围城\n";//g    7
                                    cout<<"围城—随机障碍\n";//h  8
                                    colorset(112);
                                    cout<<"自定义\n";//i   9
                                    colorset(15);
                                    f = true;
                                }
                                default: {
                                }
                                }
                            }
                            break;
                        }
                        default: {
                        }
                        }
                        break;
                    }
                    case 27: {
                        if(sound_is_on == true) {
                            PlaySound("esc.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        system("cls");
                        cout<<"新游戏\n";  //0
                        cout<<"难度\n";    //1
                        colorset(112);
                        cout<<"游戏类型\n";//2
                        colorset(15);
                        cout<<"声音\n";
                        fg = true;
                        break;
                    }
                    default: {
                    }
                    }
                }
                break;
            }
            case 3: {
                char ch;
                bool f = false;
                short y;
                if(sound_is_on) {
                    y = 1;
                } else {
                    y = 2;
                }
                system("cls");
                gotoxy(0,0);
                if(sound_is_on) {
                    cout<<"游戏声音状态：开启";
                    gotoxy(0,1);
                    colorset(112);
                    cout<<"开启";
                    colorset(15);
                    gotoxy(0,2);
                    cout<<"关闭";
                } else {
                    cout<<"游戏声音状态：关闭";
                    gotoxy(0,1);
                    cout<<"开启";
                    gotoxy(0,2);
                    colorset(112);
                    cout<<"关闭";
                    colorset(15);
                }
                while(f != true) {
                    ch = getch();
                    switch(ch) {
                    case 'w': { //上
                        if(sound_is_on == true) {
                            PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        if(y == 1) {
                            y = 2;
                        } else {
                            y--;
                        }
                        switch(y) {
                        case 1: {
                            gotoxy(0,1);
                            colorset(112);
                            cout<<"开启";
                            gotoxy(0,2);
                            colorset(15);
                            cout<<"关闭";
                            break;
                        }
                        case 2: {
                            gotoxy(0,2);
                            colorset(112);
                            cout<<"关闭";
                            gotoxy(0,1);
                            colorset(15);
                            cout<<"开启";
                            break;
                        }
                        default: {
                        }
                        }
                        break;
                    }
                    case 's': { //下
                        if(sound_is_on == true) {
                            PlaySound("updown.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        if(y == 2) {
                            y = 1;
                        } else {
                            y++;
                        }
                        switch(y) {
                        case 1: {
                            gotoxy(0,1);
                            colorset(112);
                            cout<<"开启";
                            gotoxy(0,2);
                            colorset(15);
                            cout<<"关闭";
                            break;
                        }
                        case 2: {
                            gotoxy(0,2);
                            colorset(112);
                            cout<<"关闭";
                            gotoxy(0,1);
                            colorset(15);
                            cout<<"开启";
                            break;
                        }
                        default: {
                        }
                        }
                        break;
                    }
                    case 13: {
                        if(sound_is_on == true) {
                            PlaySound("enter.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        if(y == 1) {
                            sound_is_on = true;
                            gotoxy(0,0);
                            cout<<"游戏声音状态：开启";
                        } else {
                            sound_is_on = false;
                            gotoxy(0,0);
                            cout<<"游戏声音状态：关闭";
                        }
                        break;
                    }
                    case 27: {
                        if(sound_is_on == true) {
                            PlaySound("esc.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
                        }
                        system("cls");
                        gotoxy(0,0);
                        colorset(15);
                        cout<<"新游戏\n";  //0
                        cout<<"难度\n";    //1
                        cout<<"游戏类型\n";//2
                        colorset(112);
                        cout<<"声音\n";
                        colorset(15);
                        f = true;
                        break;
                    }
                    default: {
                    }
                    }
                }
            }
            default: {
            }
            }
            break;
        default: {
        }
        }
    }
    system("cls");
}
void gameover(void)
{
    if(sound_is_on) {
        PlaySound("death.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
    }
    if(mark >= hmark) {
        hmark = mark;
    }
    system("cls");
    colorset(15);
    cout<<"游戏结束！\n";
    colorset(12);
    cout<<"您最终的得分："<<mark<<endl;
    cout<<"历史最高："<<hmark<<endl;
    colorset(15);
}
void colorset(short color)      // print color control
{
    HANDLE consolehwnd;//创建句柄
    consolehwnd = GetStdHandle(STD_OUTPUT_HANDLE);//实例化句柄
    SetConsoleTextAttribute(consolehwnd,color);//设置字体颜色
}
bool R(short r1)
{
    short r2;
    r2 = rand()%r1+1;
    if(r2 == r1) {
        return TRUE;
    } else {
        return FALSE;
    }
}

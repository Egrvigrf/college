#include"Snake.h"
short dir;
short dirold;
short len = 1;
bool snk_is_alive = true;
bool food1_notexist = true;
bool food2_is_exist = false;
unsigned long long  food2_time;
short food2_x;
short food2_y;
bool sound_is_on = true;
short maplength;
short mapwidth;
int hmark = 0;
int mark = 0;
snake head;
snake body[1000];
snake tail;
definemap dm;
char gamechoose;
char Map[200][200];
short speed;
int main ()
{
    welcome();
    while(true) {
        mark = 0;
        gameset();
        setmap();
        while(true) {
            dirchange();
            snkmove(dir,6);
            Sleep(speed);
            food1(food1_notexist);
            food2(food2_is_exist,R(125),6);
            if (!(snk_is_alive)) {
                gameover();
                break;
            }
        }
        colorset(15);
        cout<<"再试一次？\n";
        cout<<"y/n\n";
        char c=getch();
        if(c == 'n') {
            break;
        } else {
            system("cls");
            continue;
        }
    }
    return 0;
}

#include"Snake.h"
void food1(bool f)
{
    if(f) {
        colorset(12);
        int x,y;
        bool contr = TRUE;
        do {
            x=rand()%maplength+1;
            y=rand()%mapwidth+1;
            if(Map[x][y] == ' ') {
                Map[x][y]='.';
                gotoxy(x,y);
                cout<<".";
                contr = FALSE;
            }
        } while(contr == TRUE);
        colorset(14);
        food1_notexist = false;
        food2(food2_is_exist,R(10),6);
    }
}
void food2(bool f,bool r,short t)
{
    if(f == FALSE) {
        if(r == TRUE) {
            colorset(12);
            bool contr = TRUE;
            do {
                food2_x=rand()%maplength+1;
                food2_y=rand()%mapwidth+1;
                if(Map[food2_x][food2_y] == ' ') {
                    Map[food2_x][food2_y]='$';
                    gotoxy(food2_x,food2_y);
                    cout<<"$";
                    contr = FALSE;
                }
            } while(contr == TRUE);
            colorset(14);
            food2_is_exist = TRUE;
            food2_time = time(0);
            if (sound_is_on == true) {
                PlaySound("count.wav",NULL,SND_FILENAME | SND_ASYNC |  SND_SYNC);
            }
        }
    } else {
        if(time(0) - food2_time >= t) {
            Map[food2_x][food2_y] = ' ';
            gotoxy(food2_x,food2_y);
            cout<<" ";
            food2_is_exist = false;
            gotoxy(maplength+2,4);
            cout<<"                ";
        } else {
            gotoxy(maplength+2,4);
            cout<<"$消失剩余时间："<<t - (time(0) - food2_time);
        }
    }
}

#include"Snake.h"
void snkmove(short direction,short t)
{
    colorset(14);
    int headold_x = head.x;
    int headold_y = head.y;
    switch(direction) {
    case 1:
        if(headold_x == maplength) {
            head.x = 0;
            break;
        } else {
            head.x++;
            break;
        }
    case 2:
        if(headold_x == 0) {
            head.x = maplength;
            break;
        } else {
            head.x--;
            break;
        }
    case 3:
        if(headold_y == mapwidth) {
            head.y = 0;
            break;
        } else {
            head.y++;
            break;

        }
    case 4:
        if(headold_y == 0) {
            head.y = mapwidth;
            break;
        } else {
            head.y--;
            break;
        }
    default :
        break;
    }
    if(Map[head.x][head.y]=='#'||Map[head.x][head.y]=='*') { //更新蛇头坐标后后蛇头坐标遇墙或蛇身、蛇尾
        snk_is_alive = false;
    } else if(Map[head.x][head.y]==' '||Map[head.x][head.y]=='$') { //更新蛇头坐标遇' '
        if(Map[head.x][head.y]=='$') {
            if(sound_is_on) {
                PlaySound(NULL,NULL,SND_FILENAME);
                PlaySound("$.wav",NULL,SND_FILENAME | SND_ASYNC | SND_SYNC);
            }
            mark = mark+(t-(time(0) - food2_time))*3;
            gotoxy(maplength+12,0);
            colorset(10);
            cout<<mark;
            colorset(14);
            food2_is_exist = false;
            gotoxy(maplength+2,4);
            cout<<"                ";
        }
        if(len == 1) {
            tail.x = headold_x;
            tail.y = headold_y;
        }                           //蛇长=1时先更新蛇尾坐标
        Map[tail.x][tail.y] = ' '; //在地图上删除蛇尾
        gotoxy(tail.x,tail.y);
        cout<<" ";                 //在屏幕上删除蛇尾
        if(len>3||len==3) { //有一节以上蛇身时
            tail.x = body[1].x;
            tail.y = body[1].y;
            for(int n = 1; n <= len-2; n++) {
                if(n == len-2) {
                    body[n].x = headold_x;
                    body[n].y = headold_y;
                    break;
                }
                body[n].x = body[n+1].x;
                body[n].y = body[n+1].y;    //每一节蛇身的坐标更新
            }
        } else { //只有蛇头 或 只有蛇头和蛇尾时
            tail.x = headold_x;
            tail.y = headold_y;
            if(len == 2) {
                gotoxy(tail.x,tail.y);
                cout<<"*";//蛇长 = 2时移动（遇' '）后打印蛇尾'*'
            }
        }
        if(len==1) {
            Map[head.x][head.y] = '*';
            gotoxy(head.x,head.y);
            cout<<"@";  //head
        } else {
            Map[head.x][head.y] = '*';
            gotoxy(head.x,head.y);
            cout<<"@";  //head

            if(len >= 3) {
                gotoxy(body[len - 2].x,body[len - 2].y);
                cout<<"*";  //body
            }
        }//打印蛇头'@'，并把body[len-2]节的坐标打印为'*'
    } else if(Map[head.x][head.y]=='.') { //更新蛇头坐标后后蛇头坐标遇食物
        len++;
        if(len>3||len==3) {
            body[len-2].x = headold_x;
            body[len-2].y = headold_y;
        }                       //新增蛇身并记录记录其坐标
        if(len == 2) {
            tail.x = headold_x;
            tail.y = headold_y;
            gotoxy(tail.x,tail.y);
            cout<<"*";  //body
        }                       //当蛇长变为2后更新蛇尾坐标
        Map[head.x][head.y] = '*';
        gotoxy(head.x,head.y);
        cout<<"@";  //head
        gotoxy(headold_x,headold_y);
        cout<<"*";//body
        food1_notexist = true;
        if(sound_is_on) {
            PlaySound("eat.wav",NULL,SND_FILENAME | SND_ASYNC | SND_NOSTOP);
        }
        mark++;
        colorset(10);
        gotoxy(maplength+12,0);
        cout<<mark;
    }
}

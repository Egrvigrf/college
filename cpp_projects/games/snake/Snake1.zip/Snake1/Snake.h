#ifndef SNAKE_H_INCLUDED
#define SNAKE_H_INCLUDED
#include<iostream>
#include<cmath>
#include<algorithm>
#include<ctime>
#include<cstdlib>
#include<cstdio>
#include<iomanip>
#include<cstring>
#include<conio.h>
#include<windows.h>
#include<Mmsystem.h>
#pragma comment(lib,"winmm.lib")
using namespace std;
extern short dir;
extern short dirold;//x(+):1 x(-):2 y(+):3 y(-):4
struct snake {
    short x;
    short y;
};
struct definemap {
    short l;
    short w;
    bool around;
    short num;
};
extern definemap dm;
extern snake head;
extern snake body[1000];
extern snake tail;
extern short len;
extern bool snk_is_alive;
extern short speed;
extern bool food1_notexist;
extern bool food2_is_exist;
extern unsigned long long  food2_time;
extern short food2_x;
extern short food2_y;
extern bool sound_is_on;
extern short maplength;
extern short mapwidth;
extern char Map[200][200];//Map数组只记录蛇、障碍、食物的坐标，打印功能交给gotoxy()函数—以避免屏幕闪烁
extern char gamechoose;
extern int mark;
extern int hmark;
void gotoxy(short x, short y);
void setmap(void);
void food1(bool f);
void food2(bool f,bool r,short t);
void dirchange(void);
void snkmove(short direction,short t);
bool dirop(short dir,short dirold);
void welcome(void);
void gameover(void);
void colorset(short color);
void gameset(void);
void printlogo(void);
bool R(short r1);
#endif // SNAKE_H_INCLUDED
